package lk.ijse.spring.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class WebRootConfig {
}
